import{s as S}from"./storage-CGu7w2p6.js";import{r as Y,s as j}from"./ai-Mt35Rsbr.js";import{g as I}from"./utils-C-d0L4dY.js";console.log("松鼠收藏夹 (小红书): Content script loaded");let T=!1,N=null,b=!1,D=new Set,M=location.href;chrome.runtime.sendMessage({type:"GET_INSPIRATION_MODE"}).then(t=>{t?.enabled&&(b=!0,console.log("[灵感模式] 已开启"),_())}).catch(()=>{});S.getReadingMode().then(t=>{T=t,console.log("Reading mode:",T)});chrome.runtime.onMessage.addListener((t,o,r)=>{if(t.type==="READING_MODE_CHANGED"&&(T=t.enabled,console.log("Reading mode changed:",T)),t.type==="PUBLISH_TWEET"&&r({success:!1,message:"小红书发布功能开发中"}),t.type==="INSPIRATION_MODE_CHANGED"){const m=b;b=t.enabled,console.log("[灵感模式] 状态变化:",b?"开启":"关闭"),b&&!m?_():!b&&m&&K(),r({success:!0})}return!0});function B(){if(document.getElementById("twitter-ai-floating-btn"))return;const t=document.createElement("div");t.id="twitter-ai-floating-btn";const o=chrome.runtime.getURL("icons/logo.png");t.innerHTML=`
    <img src="${o}" width="40" height="40" style="border-radius: 10px; display: block;">
  `,t.style.cssText=`
    position: fixed;
    bottom: 80px;
    right: 30px;
    width: 60px;
    height: 60px;
    border-radius: 16px;
    background: transparent;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: grab;
    box-shadow: 0 4px 16px rgba(0, 0, 0, 0.3);
    z-index: 10000;
    transition: all 0.3s ease;
    user-select: none;
  `;let r=!1,m=0,u=0,p=0,c=0;t.onmousedown=s=>{r=!0,t.style.cursor="grabbing",t.style.transition="none";const e=t.getBoundingClientRect();m=s.clientX,u=s.clientY,p=e.left,c=e.top,s.preventDefault()},document.onmousemove=s=>{if(!r)return;const e=s.clientX-m,f=s.clientY-u,g=p+e,l=c+f;t.style.left=`${g}px`,t.style.top=`${l}px`,t.style.right="auto",t.style.bottom="auto"},document.onmouseup=s=>{if(!r)return;r=!1,t.style.cursor="grab",t.style.transition="all 0.3s ease";const e=t.getBoundingClientRect(),f=e.left+e.width/2,g=e.top+e.height/2,l=window.innerWidth,h=window.innerHeight,d=f,y=l-f,C=g,x=h-g,a=Math.min(d,y,C,x),i=30;a===d?(t.style.left=`${i}px`,t.style.top=`${Math.max(i,Math.min(e.top,h-e.height-i))}px`):a===y?(t.style.left=`${l-e.width-i}px`,t.style.top=`${Math.max(i,Math.min(e.top,h-e.height-i))}px`):a===C?(t.style.left=`${Math.max(i,Math.min(e.left,l-e.width-i))}px`,t.style.top=`${i}px`):(t.style.left=`${Math.max(i,Math.min(e.left,l-e.width-i))}px`,t.style.top=`${h-e.height-i}px`),t.style.right="auto",t.style.bottom="auto";const A=s.clientX-m,n=s.clientY-u;Math.sqrt(A*A+n*n)<5&&F()},t.onmouseover=()=>{r||(t.style.transform="scale(1.08) translateY(-2px)",t.style.boxShadow="0 8px 24px rgba(0, 0, 0, 0.4)")},t.onmouseout=()=>{r||(t.style.transform="scale(1) translateY(0)",t.style.boxShadow="0 4px 16px rgba(0, 0, 0, 0.3)")},document.body.appendChild(t),console.log("Floating button created")}function W(){document.addEventListener("mouseover",t=>{const r=t.target.closest('.note-item, [class*="note"], [class*="card"]');r&&(N=r)})}async function F(){if(!N){k("请先将鼠标悬停在要收藏的笔记上");return}try{await G(N),k("✓ 已收藏！")}catch(t){console.error("Failed to collect note:",t),k("✗ 收藏失败")}}async function G(t){try{const o=t.querySelector('.note-title, [class*="title"]'),r=t.querySelector('.note-content, [class*="desc"], [class*="content"]'),m=t.querySelector('.author-name, [class*="author"], [class*="name"]'),u=o?.textContent?.trim()||"",p=r?.textContent?.trim()||"",c=u?`${u}

${p}`:p;if(!c)throw new Error("无法提取笔记内容");let s=m?.textContent?.trim()||"Unknown";s=s.replace(/关注$/,"").replace(/已关注$/,"").replace(/\s*关注\s*$/,"").trim();const e=t.querySelector('a[href*="/user/profile/"]');let f="",g="";if(e){const n=e.getAttribute("href")||"";f=n.startsWith("http")?n:`https://www.xiaohongshu.com${n}`;const w=f.match(/\/user\/profile\/([a-zA-Z0-9]+)/);g=w?w[1]:""}let l="";if(e){const n=e.querySelector('img[src*="sns-avatar"]');if(n?.src)l=n.src;else{const w=e.getAttribute("href");if(w){const v=t.querySelectorAll(`a[href="${w}"]`);for(const L of v){const E=L.querySelector('img[src*="sns-avatar"]');if(E?.src){l=E.src;break}}}}}if(!l){const n=['.note-top img[src*="sns-avatar"]','.author-wrapper img[src*="sns-avatar"]','[class*="author-info"] img[src*="sns-avatar"]','.note-detail header img[src*="sns-avatar"]'];for(const w of n){const v=document.querySelector(w);if(v?.src){l=v.src;break}}}if(!l){const n=document.querySelector('.author-container img[src*="sns-avatar"], .note-scroller > div:first-child img[src*="sns-avatar"]');n?.src&&(l=n.src)}console.log("提取到的作者头像:",l?"有":"无",l?.slice(0,50));const h=t.querySelector('a[href*="/explore/"]');let d=h?new URL(h.getAttribute("href")||"",window.location.origin).href:window.location.href;d=O(d);const y=t.querySelectorAll("img[src]"),C=new Set;Array.from(y).map(n=>n.src).filter(n=>!n||n.includes("avatar")||n.includes("picasso-static")||n.includes("emoji")||n.includes("icon")||n.includes("/fe-platform/")?!1:n.includes("sns-webpic")||n.includes("xhscdn.com")).forEach(n=>C.add(n));const x=Array.from(C),a=await S.getSettings();let i=null;console.log("评论区收集设置:",a?.enableCommentCollection?"已开启":"未开启"),a?.enableCommentCollection&&(console.log("开始收集评论区内容..."),i=P(s));const A={id:I(),tweetId:Z(d),tweetUrl:d,author:s,authorHandle:g||s.toLowerCase().replace(/\s+/g,"_"),authorProfileUrl:f||void 0,authorAvatar:l||void 0,content:c,platform:"xiaohongshu",keywords:[],collectTime:Date.now(),media:x,stats:{likes:0,retweets:0,replies:0},authorThread:i?.authorThread||void 0,commentHighlights:i?.otherComments.length?i.otherComments.join(`
`):void 0};if(console.log("Collecting note:",A),await S.saveTweet(A),a&&a.apiKey)try{let n=c;if(i?.authorThread&&(n=`${c}

【作者补充内容】
${i.authorThread}`),a.enableImageRecognition&&x.length>0){console.log(`图片识别已启用，共 ${x.length} 张图片，开始识别...`);try{const v=x.slice(0,9),E=(await Promise.all(v.map(($,U)=>Y(a,$).then(q=>(console.log(`图片 ${U+1}/${v.length} 识别完成`),q)).catch(q=>(console.warn(`图片 ${U+1} 识别失败:`,q),""))))).filter($=>$).join(`

---

`);E&&(n=`${c}

【图片内容】
${E}`,console.log("图片识别完成，识别出文字:",E.slice(0,100)))}catch(v){console.error("图片识别失败:",v)}}i?.otherComments.length&&(n=`${n}

【评论区观点】
${i.otherComments.join(`
`)}`);const w=await j(a,n);await S.updateTweet(A.id,{summary:w.summary,keywords:w.keywords,sentiment:w.sentiment,category:w.category}),console.log("AI summary completed")}catch(n){console.error("Failed to get AI summary:",n)}}catch(o){throw console.error("Failed to collect note:",o),o}}function Z(t){const o=t.match(/\/explore\/([a-zA-Z0-9]+)/);return o?o[1]:I()}function O(t){try{const o=new URL(t);return`${o.origin}${o.pathname}`}catch{return t}}function P(t){const o={authorThread:"",otherComments:[]},r=[],m=new Set,u=[".comment-item",".comments-container .comment",'[class*="comment-item"]','[class*="CommentItem"]',".note-comment"];let p=[];for(const c of u){const s=document.querySelectorAll(c);if(s.length>0){p=Array.from(s),console.log(`找到评论元素: ${c}, 数量: ${s.length}`);break}}return p.length===0?(console.log("未找到评论区元素"),o):(p.forEach(c=>{const s=[".user-name",".author-name",'[class*="nickname"]','[class*="userName"]','[class*="name"]'];let e="";for(const h of s){const d=c.querySelector(h);if(d?.textContent?.trim()){e=d.textContent.trim();break}}const f=[".comment-content",".content",'[class*="content"]','[class*="text"]'];let g="";for(const h of f){const d=c.querySelector(h);if(d?.textContent?.trim()){g=d.textContent.trim();break}}if(!g)return;if(e&&(e===t||c.querySelector('[class*="author-tag"]')||c.querySelector('[class*="作者"]')))r.push(g);else if(e){const h=g.length>100?g.slice(0,100)+"...":g,d=`${e}: ${h}`;m.add(d)}}),o.authorThread=r.join(`

`),o.otherComments=Array.from(m).slice(0,10),console.log("评论区收集结果:",{authorThread:o.authorThread.slice(0,50),commentsCount:o.otherComments.length}),o)}function k(t){const o=document.createElement("div");o.textContent=t,o.style.cssText=`
    position: fixed;
    top: 80px;
    right: 80px;
    background: #1d9bf0;
    color: white;
    padding: 16px 24px;
    border-radius: 12px;
    box-shadow: 0 4px 12px rgba(29, 155, 240, 0.3);
    z-index: 10001;
    font-size: 14px;
    font-weight: 500;
    animation: slideIn 0.3s ease-out;
  `,document.body.appendChild(o),setTimeout(()=>{o.style.animation="slideOut 0.3s ease-out",setTimeout(()=>o.remove(),300)},2e3)}function _(){console.log("[灵感模式] 初始化采集..."),z()?H():Q(),J()}function K(){console.log("[灵感模式] 停止采集")}function z(){return location.pathname.includes("/explore/")||location.pathname.includes("/discovery/item/")||location.pathname.includes("/search_result/")}function J(){setInterval(()=>{if(location.href!==M){if(M=location.href,console.log("[灵感模式] URL 变化:",M),!b)return;z()&&setTimeout(()=>H(),1e3)}},500)}function Q(){const t=new IntersectionObserver(m=>{b&&m.forEach(u=>{if(u.isIntersecting){const p=u.target;V(p)}})},{threshold:.5});function o(){document.querySelectorAll('.note-item, [class*="note-item"], .feeds-page section, [class*="NoteItem"]').forEach(u=>{u.hasAttribute("data-inspiration-observed")||(u.setAttribute("data-inspiration-observed","true"),t.observe(u))})}o(),new MutationObserver(()=>{b&&o()}).observe(document.body,{childList:!0,subtree:!0})}function V(t){try{const o=t.querySelector('a[href*="/explore/"], a[href*="/discovery/item/"]');if(!o)return;const r=o.getAttribute("href")||"",m=r.startsWith("http")?r:`https://www.xiaohongshu.com${r}`;if(D.has(m))return;D.add(m);const p=t.querySelector('.title, [class*="title"], [class*="Title"]')?.textContent?.trim()||"",s=t.querySelector('.desc, [class*="desc"], [class*="content"]')?.textContent?.trim()?.slice(0,100)||"";let f=t.querySelector('.author-name, [class*="author"], .name, [class*="nickname"]')?.textContent?.trim()||"未知作者";f=f.replace(/关注$/,"").replace(/已关注$/,"").trim();const l=t.querySelector('img[src*="sns-avatar"]')?.src||"",d=t.querySelector('img[src*="sns-webpic"], img[src*="xhscdn"]')?.src||"",y={id:I(),platform:"xiaohongshu",author:f,authorAvatar:l||void 0,title:p||void 0,summary:s||p||void 0,url:m,thumbnail:d||void 0,capturedAt:Date.now(),isDetail:!1};console.log("[灵感模式] 采集列表项:",y.title||y.summary?.slice(0,20)),chrome.runtime.sendMessage({type:"INSPIRATION_ITEM_CAPTURED",item:y})}catch(o){console.error("[灵感模式] 采集列表项失败:",o)}}async function H(){if(b)try{const t=O(location.href);await new Promise(a=>setTimeout(a,500));const r=document.querySelector('.title, [class*="title"], h1')?.textContent?.trim()||"",u=document.querySelector('.note-content, [class*="content"], .desc, #detail-desc')?.textContent?.trim()||"";let c=document.querySelector('.author-name, [class*="author"], .user-name, [class*="nickname"]')?.textContent?.trim()||"未知作者";c=c.replace(/关注$/,"").replace(/已关注$/,"").trim();let s="";const e=document.querySelector('a[href*="/user/profile/"]');if(e){const a=e.querySelector('img[src*="sns-avatar"]');a?.src&&(s=a.src)}let f="",g="";if(e){const a=e.getAttribute("href")||"";f=a.startsWith("http")?a:`https://www.xiaohongshu.com${a}`;const i=f.match(/\/user\/profile\/([a-zA-Z0-9]+)/);g=i?i[1]:""}const l=document.querySelectorAll('.note-slider img[src*="sns-webpic"], .swiper-slide img[src*="xhscdn"]'),h=Array.from(l).map(a=>a.src).filter(a=>a&&!a.includes("avatar")),d=await S.getSettings();let y=null;d?.enableCommentCollection&&(y=P(c));const C=r?`${r}

${u}`:u;if(!C&&h.length===0){console.log("[灵感模式] 详情页内容为空，跳过");return}const x={id:I(),platform:"xiaohongshu",author:c,authorHandle:g||void 0,authorAvatar:s||void 0,authorProfileUrl:f||void 0,title:r||void 0,content:C||void 0,url:t,thumbnail:h[0]||void 0,media:h.length>0?h:void 0,capturedAt:Date.now(),isDetail:!0,authorThread:y?.authorThread||void 0,commentHighlights:y?.otherComments.length?y.otherComments.join(`
`):void 0};console.log("[灵感模式] 采集详情页:",x.title?.slice(0,20)||x.content?.slice(0,20)),chrome.runtime.sendMessage({type:"INSPIRATION_ITEM_CAPTURED",item:x}),D.add(t)}catch(t){console.error("[灵感模式] 采集详情页失败:",t)}}const X=document.createElement("style");X.textContent=`
  @keyframes slideIn {
    from {
      transform: translateX(400px);
      opacity: 0;
    }
    to {
      transform: translateX(0);
      opacity: 1;
    }
  }

  @keyframes slideOut {
    from {
      transform: translateX(0);
      opacity: 1;
    }
    to {
      transform: translateX(400px);
      opacity: 0;
    }
  }
`;document.head.appendChild(X);function R(){console.log("Initializing Twitter AI Assistant for 小红书..."),B(),W(),console.log("Twitter AI Assistant for 小红书 initialized!")}document.readyState==="loading"?document.addEventListener("DOMContentLoaded",R):R();
