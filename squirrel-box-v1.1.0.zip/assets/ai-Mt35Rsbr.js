async function u(o,e,n){if(!o.apiKey||!o.baseUrl)throw new Error("API配置未完成，请前往设置页面配置");const r=o.model||"gpt-4o",a=await fetch(`${o.baseUrl}/chat/completions`,{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${o.apiKey}`},body:JSON.stringify({model:r,messages:e,temperature:.7})});if(!a.ok){const s=await a.text();throw new Error(`AI调用失败: ${a.status} ${s}`)}return(await a.json()).choices[0]?.message?.content||""}async function y(o){try{const n=await(await fetch(o)).blob();return new Promise((r,a)=>{const t=new FileReader;t.onloadend=()=>{const s=t.result;r(s)},t.onerror=a,t.readAsDataURL(n)})}catch(e){throw console.error("图片转换 base64 失败:",e),e}}async function h(o,e){const n=o.visionApiKey||o.apiKey,r=o.visionBaseUrl||o.baseUrl,a=o.visionModel||o.model||"gpt-4o";if(!n||!r)throw new Error("API配置未完成，请前往设置页面配置");console.log("使用视觉模型:",a,"| API:",r);const t=`请仔细分析这张图片，提取其中的所有文字内容。
要求：
1. 完整提取图片中的所有文字，保持原有的排版和段落结构
2. 如果是多图拼接，请按图片顺序整理文字
3. 忽略水印、装饰性文字
4. 只返回提取的文字内容，不要添加任何额外说明`;let s=e;try{s=await y(e),console.log("图片已转换为 base64")}catch(l){console.warn("图片转换失败，尝试直接使用 URL:",l)}const c={...o,apiKey:n,baseUrl:r,model:a};return await u(c,[{role:"user",content:[{type:"text",text:t},{type:"image_url",image_url:{url:s}}]}])}const d=`1. **核心摘要**（使用 Markdown 格式输出，提高可读性）：
   - 保留原文的核心论点和关键细节，不限制字数
   - 如果有具体的方法、步骤、规则，必须完整保留
   - 保留数据、示例、对比等重要信息
   - 保持原文的逻辑结构和重点层次
   - 根据内容复杂度决定摘要长度，宁可详细也不要丢失重点

   **Markdown 格式要求**：
   - 使用 **加粗** 突出关键概念和重要观点
   - 多个要点时使用列表（- 或 1. 2. 3.）
   - 有层次的内容可以用分段
   - 简短内容（<50字）可以不用 Markdown
   - 不要使用标题语法（#），保持内容紧凑
   - 代码或命令用 \`反引号\` 包裹

   特别注意：
   - 如果原文包含具体的操作指令、提示词、配置项等，必须完整保留
   - 如果原文有列举的要点（如：删除、假设、输出、禁止等），必须列出所有要点
   - 不要用"介绍了XX"这种过于概括的表达，要说明具体内容是什么
   - 对于干货内容，摘要可以更长，确保不遗漏关键信息

2. **关键词提取**（3-5个）：
   - 提取最核心的主题词
   - 优先选择专业术语和核心概念
   - 避免过于宽泛的词汇

3. **情感分析**：
   - positive: 积极、正面、乐观的内容
   - neutral: 客观陈述、中立观点
   - negative: 批评、负面、消极的内容

4. **内容分类**（选择最匹配的一个）：
   - 技术：编程、开发、工具、框架、技术方案
   - 产品：产品设计、功能特性、用户体验、产品思考
   - 营销：市场策略、增长方法、推广技巧、销售经验
   - 资讯：行业新闻、事件报道、趋势动态
   - 观点：个人见解、深度思考、评论分析
   - 生活：日常分享、生活感悟、娱乐内容
   - 其他：不属于以上类别`;async function g(o,e){const r=`作为一个专业的内容分析助手，请分析以下推文/笔记内容，提供精准的摘要和分类：

任务要求：
${o.customSummaryPrompt||d}

原始内容：
${e}

请严格按照以下JSON格式返回（不要添加任何markdown标记）：
{
  "summary": "这里是核心摘要，根据内容复杂度自行决定长度，必须保留所有关键细节和具体内容",
  "keywords": ["关键词1", "关键词2", "关键词3"],
  "sentiment": "positive",
  "category": "技术"
}`,a=await u(o,[{role:"user",content:r}]);try{const t=JSON.parse(a);return{summary:t.summary||e.slice(0,100),keywords:t.keywords||[],sentiment:t.sentiment||"neutral",category:t.category||"其他"}}catch{return{summary:e.slice(0,100),keywords:[],sentiment:"neutral",category:"其他"}}}const w=`你是一位专业的社交媒体内容创作者，专注于 Twitter/X 平台。

**Twitter 排版规则**：
1. 使用空行分段，让内容更易读
2. 重要观点单独成段
3. 适当使用 emoji 增加表现力（但不要过度）
4. 列表项用换行分隔，可用数字或 emoji 作为列表标记
5. 长文需要分成多个段落，每段聚焦一个要点
6. 开头要有吸引力，结尾可以有 call-to-action

**内容要求**：
1. 观点清晰，表达有力
2. 避免空洞的套话
3. 如有数据或案例，要具体
4. 保持真实感和个人风格
5. 适当引发讨论或互动

**格式示例**：
🔥 开头抓住注意力

核心观点第一段
解释或展开

要点一
要点二
要点三

总结或 call-to-action`;async function f(o,e,n){const r={zh:"中文",en:"English",ja:"日本語",ko:"한국어"},a={professional:"专业严肃",casual:"轻松幽默",concise:"简洁精炼",detailed:"详细解释",custom:e.customPrompt||"自然流畅"},t={short:"短推（<140字，1-2段）",standard:"标准（140-280字，2-4段）",long:"长文（需要分段，每段不超过280字，可以有5-8段）"};let c=`${o.customCreationPrompt||w}

---

请基于以下要求创作推文：

**主题**：${e.topic}
**语言**：${r[e.language]}
**风格**：${a[e.tone]}
**长度**：${t[e.length]}
`;n.length>0&&(c+=`
**参考素材**：
`,n.forEach((i,p)=>{c+=`${p+1}. ${i.summary||i.content}
`})),c+=`
---

请生成3个不同版本的推文，每个版本风格略有不同。
**重要**：每个版本之间用 --- 分隔，直接输出推文内容，不要加"版本1"等标签。
确保排版清晰，适合直接发布到 Twitter。`;const m=await u(o,[{role:"user",content:c}]),l=m.split("---").map(i=>i.trim()).filter(i=>i.length>0);return l.length>0?l:[m]}export{w as a,u as c,d,f as g,h as r,g as s};
